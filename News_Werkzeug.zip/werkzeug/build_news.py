#!/usr/bin/env python3
"""Baut den News-/Blog-Bereich von projectp-distribution.com.

Benutzung (im Ordner, in dem index.html liegt):
    python3 build_news.py

Liest alle Dateien in content/*.md und erzeugt:
    news.html, news-<name>.html, sitemap.xml, feed.xml, robots.txt
Voraussetzung: pip install markdown
"""
import glob, html, json, os, re, sys
from datetime import datetime, timezone
import markdown

BASE = "https://www.projectp-distribution.com"
ORG = "Project P Distribution GmbH"
HERE = os.path.dirname(os.path.abspath(__file__))

MONTHS_DE = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"]
MONTHS_EN = ["January","February","March","April","May","June","July","August","September","October","November","December"]

UI = {
    "en": {"home":"Home","news":"News","contact":"Contact","back":"All news","read":"Read article","min":"min read",
           "cta_h":"Want to bring your product to Germany?","cta_p":"Tell us about your product. We read every message and reply when there is a potential fit.",
           "cta_b":"Get in touch","more":"More from our news","imprint":"Legal notice","privacy":"Privacy policy",
           "claim":"Food distributor Germany · FMCG distribution","by":"By"},
    "de": {"home":"Start","news":"News","contact":"Kontakt","back":"Alle Beiträge","read":"Beitrag lesen","min":"Min. Lesezeit",
           "cta_h":"Sie möchten Ihr Produkt nach Deutschland bringen?","cta_p":"Erzählen Sie uns von Ihrem Produkt. Wir lesen jede Nachricht und melden uns, wenn eine Zusammenarbeit passen könnte.",
           "cta_b":"Kontakt aufnehmen","more":"Weitere Beiträge","imprint":"Impressum","privacy":"Datenschutz",
           "claim":"Lebensmittel Distributor Deutschland · FMCG distribution","by":"Von"},
}

def fmt_date(d, lang):
    dt = datetime.strptime(d, "%Y-%m-%d")
    if lang == "de":
        return "%d. %s %d" % (dt.day, MONTHS_DE[dt.month-1], dt.year)
    return "%d %s %d" % (dt.day, MONTHS_EN[dt.month-1], dt.year)

def logo(prefix, word, pi, sub):
    return f'''<svg viewBox="0 0 400 130" role="img" aria-label="Logo {ORG}">
<defs><linearGradient id="{prefix}" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="#A50014"/><stop offset="100%" stop-color="#C8001A"/></linearGradient></defs>
<rect x="0" y="18" width="7" height="80" fill="url(#{prefix})" rx="3.5"/>
<text x="24" y="82" font-family="'Bebas Neue', Impact, 'Arial Narrow', sans-serif" font-size="62" fill="{word}" letter-spacing="0.04em">PROJECT</text>
<text x="214" y="68" font-family="'EB Garamond', Garamond, 'Times New Roman', serif" font-size="108" fill="{pi}">&#960;</text>
<rect x="24" y="92" width="260" height="4" fill="url(#{prefix})" rx="2"/>
<text x="24" y="113" font-family="'Montserrat', Helvetica, Arial, sans-serif" font-weight="300" font-size="12" fill="{sub}" letter-spacing="0.32em">DISTRIBUTION GMBH</text>
</svg>'''

def header(lang, current):
    u = UI[lang]
    cur = lambda k: ' aria-current="page"' if current == k else ""
    return f'''<a class="skip" href="#main" style="position:absolute;left:-9999px">Skip to content</a>
<header class="nh"><div class="bar">
<a class="logo" href="index.html" aria-label="{ORG}">{logo("gN", "#07070F", "#07070F", "#7A7A82")}</a>
<nav aria-label="Main"><a class="hide-s" href="index.html">{u["home"]}</a><a href="news.html"{cur("news")}>{u["news"]}</a><a class="nav-cta" href="index.html#kontakt">{u["contact"]}</a></nav>
</div></header>'''

def footer(lang):
    u = UI[lang]
    return f'''<footer><div class="wrap">
<div class="fgrid">
<div><div class="logo">{logo("gF", "#F8F8F4", "#F8F8F4", "#7A7A82")}</div><div class="ftag">Bridging markets. Building brands.</div></div>
<div class="flinks"><a href="index.html">{u["home"]}</a><a href="news.html">{u["news"]}</a><a href="index.html#kontakt">{u["contact"]}</a><a href="index.html#impressum">{u["imprint"]}</a><a href="index.html#datenschutz">{u["privacy"]}</a></div>
</div>
<div class="fbottom"><div>© {datetime.now().year} {ORG} · Friedenstraße 7, 12107 Berlin · HRB 292473</div><div>{u["claim"]}</div></div>
</div></footer>'''

def page(lang, title, desc, canonical, body, extra_head="", og_type="website"):
    t = html.escape(title, quote=True); d = html.escape(desc, quote=True)
    return f'''<!DOCTYPE html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="only light">
<meta name="supported-color-schemes" content="light">
<title>{t}</title>
<meta name="description" content="{d}">
<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large">
<meta name="author" content="{ORG}">
<link rel="canonical" href="{canonical}">
<link rel="alternate" type="application/rss+xml" title="{ORG} – News" href="{BASE}/feed.xml">
<meta property="og:type" content="{og_type}">
<meta property="og:site_name" content="{ORG}">
<meta property="og:title" content="{t}">
<meta property="og:description" content="{d}">
<meta property="og:url" content="{canonical}">
<meta name="twitter:card" content="summary">
{extra_head}
<link rel="stylesheet" href="site.css">
</head>
<body>
{body}
</body>
</html>
'''

def parse(path):
    raw = open(path, encoding="utf-8").read().lstrip("﻿")
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)$", raw, re.S)
    if not m:
        sys.exit(f"{path}: Kopfbereich (---) fehlt")
    meta = {}
    for line in m.group(1).splitlines():
        if ":" in line and not line.strip().startswith("#"):
            k, v = line.split(":", 1)
            meta[k.strip().lower()] = v.strip().strip('"').strip("'")
    for need in ("title", "date", "summary"):
        if not meta.get(need):
            sys.exit(f"{path}: Feld '{need}' fehlt")
    meta.setdefault("category", "News")
    meta.setdefault("lang", "en")
    if meta["lang"] not in UI:
        sys.exit(f"{path}: lang muss en oder de sein")
    meta["slug"] = os.path.splitext(os.path.basename(path))[0]
    meta["slug"] = re.sub(r"^\d{4}-\d{2}-\d{2}-", "", meta["slug"])
    meta["file"] = "news-%s.html" % meta["slug"]
    md = markdown.Markdown(extensions=["extra", "sane_lists"])
    meta["html"] = md.convert(m.group(2).strip())
    words = len(re.sub(r"<[^>]+>", " ", meta["html"]).split())
    meta["minutes"] = max(1, round(words / 200))
    return meta

def card(p):
    u = UI[p["lang"]]
    return f'''<a class="card" href="{p["file"]}" hreflang="{p["lang"]}">
<div class="meta"><span class="chip">{html.escape(p["category"])}</span><time datetime="{p["date"]}">{fmt_date(p["date"], p["lang"])}</time><span>{p["lang"].upper()}</span></div>
<h2>{html.escape(p["title"])}</h2>
<p>{html.escape(p["summary"])}</p>
<span class="more">{u["read"]} →</span></a>'''

def build_post(p, others):
    u = UI[p["lang"]]
    url = f"{BASE}/{p['file']}"
    ld = {"@context":"https://schema.org","@type":"Article","headline":p["title"],"description":p["summary"],
          "datePublished":p["date"],"dateModified":p.get("updated", p["date"]),"inLanguage":p["lang"],
          "mainEntityOfPage":url,"url":url,
          "author":{"@type":"Organization","name":ORG,"url":BASE+"/"},
          "publisher":{"@type":"Organization","name":ORG,"url":BASE+"/"}}
    extra = '<script type="application/ld+json">%s</script>' % json.dumps(ld, ensure_ascii=False)
    more = ""
    if others:
        more = f'''<section class="more-posts"><div class="wrap"><h2>{u["more"]}</h2><div class="cards">{"".join(card(o) for o in others)}</div></div></section>'''
    body = f'''{header(p["lang"], "news")}
<main id="main">
<article class="post">
<div class="crumb"><a href="news.html">← {u["back"]}</a></div>
<div class="meta"><span class="chip">{html.escape(p["category"])}</span><time datetime="{p["date"]}">{fmt_date(p["date"], p["lang"])}</time><span>{p["minutes"]} {u["min"]}</span></div>
<h1>{html.escape(p["title"])}</h1>
<p class="lede">{html.escape(p["summary"])}</p>
<div class="prose">
{p["html"]}
</div>
<div class="cta"><h2>{u["cta_h"]}</h2><p>{u["cta_p"]}</p><a class="btn btn-primary" href="index.html#kontakt">{u["cta_b"]}</a></div>
</article>
{more}
</main>
{footer(p["lang"])}'''
    return page(p["lang"], f'{p["title"]} | {ORG}', p["summary"], url, body, extra, "article")

def build_hub(posts):
    cards = "".join(card(p) for p in posts) if posts else '<p class="empty">Coming soon.</p>'
    ld = {"@context":"https://schema.org","@type":"Blog","name":f"{ORG} – News & Insights","url":f"{BASE}/news.html",
          "publisher":{"@type":"Organization","name":ORG,"url":BASE+"/"},
          "blogPost":[{"@type":"BlogPosting","headline":p["title"],"url":f"{BASE}/{p['file']}","datePublished":p["date"]} for p in posts]}
    extra = '<script type="application/ld+json">%s</script>' % json.dumps(ld, ensure_ascii=False)
    body = f'''{header("en", "news")}
<main id="main">
<section class="nhero"><div class="bgpi" aria-hidden="true">&#960;</div><div class="wrap">
<div class="mark"><span class="pi" aria-hidden="true">&#960;</span><span>{ORG}</span></div>
<h1>News &amp; <em>Insights</em></h1>
<p>Practical insights for producers and brands entering the German food retail market, and news from Project P Distribution.</p>
<p class="de">Praxiswissen für Hersteller und Marken auf dem Weg in den deutschen Lebensmitteleinzelhandel.</p>
</div></section>
<div class="wrap"><div class="cards">{cards}</div></div>
</main>
{footer("en")}'''
    return page("en", f"News & Insights | {ORG}",
                "Practical insights for producers and brands entering the German food retail market, plus news from Project P Distribution GmbH, Berlin.",
                f"{BASE}/news.html", body, extra)

def main():
    os.chdir(HERE)
    files = sorted(glob.glob("content/*.md"))
    posts = [parse(f) for f in files]
    slugs = [p["slug"] for p in posts]
    if len(set(slugs)) != len(slugs):
        sys.exit("Doppelte Dateinamen (nach Entfernen des Datums)")
    posts.sort(key=lambda p: p["date"], reverse=True)

    for old in glob.glob("news-*.html"):
        os.remove(old)
    for p in posts:
        others = [o for o in posts if o["slug"] != p["slug"]][:2]
        open(p["file"], "w", encoding="utf-8").write(build_post(p, others))
    open("news.html", "w", encoding="utf-8").write(build_hub(posts))

    urls = [(BASE + "/", None), (BASE + "/news.html", posts[0]["date"] if posts else None)]
    urls += [(f"{BASE}/{p['file']}", p.get("updated", p["date"])) for p in posts]
    sm = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for u, d in urls:
        sm.append("<url><loc>%s</loc>%s</url>" % (u, "<lastmod>%s</lastmod>" % d if d else ""))
    sm.append("</urlset>")
    open("sitemap.xml", "w", encoding="utf-8").write("\n".join(sm) + "\n")

    items = []
    for p in posts[:20]:
        pub = datetime.strptime(p["date"], "%Y-%m-%d").replace(tzinfo=timezone.utc).strftime("%a, %d %b %Y 08:00:00 +0000")
        items.append(f"<item><title>{html.escape(p['title'])}</title><link>{BASE}/{p['file']}</link><guid>{BASE}/{p['file']}</guid><pubDate>{pub}</pubDate><description>{html.escape(p['summary'])}</description></item>")
    feed = f'''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel><title>{ORG} – News</title><link>{BASE}/news.html</link><description>News and insights on entering the German food retail market.</description><language>en</language>
{chr(10).join(items)}
</channel></rss>
'''
    open("feed.xml", "w", encoding="utf-8").write(feed)
    open("robots.txt", "w", encoding="utf-8").write(f"User-agent: *\nAllow: /\n\nSitemap: {BASE}/sitemap.xml\n")
    print("OK:", len(posts), "Beitraege ->", ", ".join(p["file"] for p in posts))

if __name__ == "__main__":
    main()
