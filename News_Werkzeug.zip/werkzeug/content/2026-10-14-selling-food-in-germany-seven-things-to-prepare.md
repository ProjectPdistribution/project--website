---
title: Selling food in Germany: seven things to prepare before you talk to retail
date: 2026-10-14
category: For Producers
lang: en
summary: A short checklist for producers who want to enter the German market, from labelling and packaging registration to price lists and claims.
---
Many good products never reach a German shelf because the basics were not ready when the first conversation with retail happened. This checklist covers the points we see most often. It is general information, not legal advice. Please confirm the details for your product with the competent authority or an adviser.

## 1. Check your shelf: is it really new?

Before anything else, look at what German shoppers can already buy. Check the online shops of the large supermarket chains and Amazon.de, and look at shelves in person if you can. Compare taste, format, pack size and price. If a very similar product exists, you need a clear reason why yours is different.

## 2. German-language labelling

Food sold in Germany needs a label in German. Under the EU Food Information Regulation (Regulation (EU) No 1169/2011) this includes, among other things:

- the name of the food and the ingredient list, with allergens highlighted
- the nutrition declaration
- the best-before date and storage conditions
- the name and address of the food business operator responsible within the EU

If you do not have a company in the EU, an importer in Germany can be named on the label.

## 3. Packaging registration

Germany requires registration of packaging. Under the German Packaging Act (VerpackG), whoever first places filled packaging on the German market must register with the LUCID packaging register and take part in a licensing system for the packaging. Clarify early who this is in your supply chain, because retailers will ask for proof.

## 4. Beverages: deposit rules

Many single-use beverage bottles and cans in Germany carry a deposit (Pfand), and the products must be registered with the deposit system operator DPG. Check whether your beverage and packaging fall under these rules before you ship.

## 5. Product data and price list

Retail buyers need clean data to work with. Prepare:

- EAN/GTIN codes for each product and pack level
- pack, carton and pallet dimensions and weights
- shelf life and minimum order quantity
- a price list in euros, with the delivery terms (Incoterms) stated

## 6. Check your claims

What you may say on the pack is regulated. Health and nutrition claims must follow EU rules, and some product names are protected. A typical example is plant-based products, which cannot use dairy terms such as "milk" for the product name. Have your claims reviewed before printing labels.

## 7. Plan in months, not weeks

A listing is rarely quick. Retailers often start with a limited test, look at sales and then decide on more. Samples, data, labels and logistics all take time. A realistic plan and a partner who knows the process help you avoid costly mistakes.

If you want to talk about your product and the German market, we are happy to hear from you.

*This article is general information and does not replace legal or regulatory advice.*
