---
title: SIAL Paris 2026: The products we are looking for
date: 2026-10-14
category: Trade Shows
lang: en
summary: SIAL Paris runs from 17 to 21 October. Here is what kind of products we want to meet there, and what to bring to a first conversation.
---
SIAL Paris takes place from **17 to 21 October 2026** at Paris Nord Villepinte. I will be there to meet producers and brands that want to enter the German food retail market.

## Who we are

Project P Distribution is a Berlin-based importer and distributor. We bring food and beverage products that are not yet available in Germany to German retail, with a focus on EDEKA. We choose products with market data, not gut feeling: before we recommend a product, we look at what is already on the shelf, at price points and at what German shoppers respond to.

## What we are looking for

- **Genuinely new for Germany.** Products you cannot yet buy in German supermarkets, or only in a very different form.
- **A clear point of difference.** Taste, ingredients, format or story. If a shopper cannot see the difference in three seconds, it is hard to win the shelf.
- **A format that works in German retail.** Sensible pack sizes, a good shelf life and a price point that fits the category.
- **Export readiness.** Stable supply, product data, certificates and a team that answers quickly.

Categories we follow most closely: snacking and delicatessen, non-alcoholic beverages, bakery and confectionery, nuts and dried fruit, oils, spices and preserves.

## What to bring to a first meeting

1. A product sample, if possible.
2. A specification sheet with ingredients and allergens.
3. Your price list (ex-works) and minimum order quantities.
4. Shelf life, pack and pallet data, and EAN codes.
5. Your food safety certificates.

You do not need everything on day one. A short conversation is enough to find out whether there is a fit.

## How to reach us

Use the contact form on our website and mention "SIAL", or message me on [LinkedIn](https://www.linkedin.com/in/assad-abou-chaker-b65050442). We cannot take every product, and we will tell you early if a product is not the right fit for the German market. That saves both sides time.

*Assad Abou-Chaker, Founder & Business Development, Project P Distribution GmbH*
