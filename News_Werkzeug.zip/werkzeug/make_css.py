import re
src = open("/mnt/user-data/outputs/index.html", encoding="utf-8").read()

def between(a, b, incl_b=True):
    i = src.index(a)
    j = src.index(b, i) + (len(b) if incl_b else 0)
    return src[i:j]

# 1. embedded fonts
fonts = "\n".join(re.findall(r"@font-face\{[^}]*\}", src))
assert fonts.count("@font-face") == 6

# 2. tokens + base
base = between(":root{", "p{max-width:68ch}")
# 3. buttons
btn = between(".btn{", ".btn-dark:hover{filter:brightness(1.5)}")
# 4. footer
footer = between("footer{background", ".fbottom{")
footer = footer + src[src.index(".fbottom{") + len(".fbottom{"): src.index("}", src.index(".fbottom{"))+1]
footer = footer.replace(".fbottom{.fbottom{", ".fbottom{")
# 5. skip link + mark
skip = between(".skip:focus{", "}")
mark = between(".mark{", ".mark span{") 
mark += src[src.index(".mark span{") + len(".mark span{"): src.index("}", src.index(".mark span{"))+1]

news = r"""
/* ---------- NEWS / BLOG ---------- */
.nh{position:sticky;top:0;z-index:90;background:rgba(248,248,244,.97);border-bottom:1px solid var(--line)}
.nh .bar{max-width:var(--maxw);margin:0 auto;padding:12px var(--pad);display:flex;align-items:center;justify-content:space-between;gap:20px}
.nh .logo svg{width:150px;height:49px}
.nh nav{display:flex;align-items:center;gap:26px}
.nh nav a{font-size:.79rem;letter-spacing:.14em;text-transform:uppercase;text-decoration:none;color:var(--steel);transition:color .2s}
.nh nav a:hover,.nh nav a[aria-current="page"]{color:var(--burg)}
.nh nav a.nav-cta{color:var(--night);font-weight:600}
.pi{font-family:'EB Garamond',Garamond,serif;font-weight:400}

.nhero{background:var(--night);color:var(--warm);position:relative;overflow:hidden;padding:clamp(56px,9vw,110px) 0 clamp(48px,7vw,84px)}
.nhero .bgpi{position:absolute;right:-2vw;top:-6vw;font-family:'EB Garamond',Garamond,serif;font-size:clamp(14rem,34vw,30rem);line-height:1;color:rgba(165,0,20,.14);pointer-events:none;user-select:none}
.nhero .mark span{color:#9A9AA2}
.nhero h1{color:var(--warm);position:relative}
.nhero h1 em{font-style:normal;color:var(--burg2)}
.nhero p{position:relative;color:#C9C9C4;margin-top:22px;font-size:1.05rem}
.nhero p.de{color:#8A8A92;margin-top:10px;font-size:.92rem}

.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,320px),1fr));gap:28px;padding:clamp(36px,6vw,72px) 0 clamp(56px,8vw,100px)}
.card{display:flex;flex-direction:column;background:#fff;border:1px solid var(--line);border-top:3px solid var(--burg);padding:28px 28px 24px;text-decoration:none;color:inherit;transition:transform .2s ease,box-shadow .2s ease}
.card:hover{transform:translateY(-4px);box-shadow:0 14px 36px rgba(7,7,15,.09)}
.card .meta{display:flex;flex-wrap:wrap;gap:10px 14px;align-items:center;font-size:.72rem;letter-spacing:.14em;text-transform:uppercase;color:var(--steel);margin-bottom:16px}
.chip{display:inline-block;background:var(--burg);color:#fff;font-weight:600;padding:4px 9px;letter-spacing:.12em}
.card h2{font-size:clamp(1.7rem,2.6vw,2.15rem);line-height:1.02;margin-bottom:14px}
.card p{font-size:.95rem;color:#3A3A44;margin-bottom:22px;flex:1}
.card .more{font-size:.76rem;font-weight:600;letter-spacing:.16em;text-transform:uppercase;color:var(--burg)}
.empty{padding:60px 0;color:var(--steel)}

.post{max-width:760px;margin:0 auto;padding:clamp(40px,6vw,76px) var(--pad) clamp(40px,6vw,72px)}
.crumb{font-size:.74rem;letter-spacing:.14em;text-transform:uppercase;margin-bottom:28px}
.crumb a{color:var(--steel);text-decoration:none}
.crumb a:hover{color:var(--burg)}
.post .meta{display:flex;flex-wrap:wrap;gap:10px 16px;align-items:center;font-size:.74rem;letter-spacing:.14em;text-transform:uppercase;color:var(--steel);margin-bottom:20px}
.post h1{font-size:clamp(2.5rem,6.2vw,4.3rem);margin-bottom:26px}
.post .lede{font-size:1.18rem;line-height:1.7;color:#2A2A34;font-weight:400;margin-bottom:34px;padding-bottom:30px;border-bottom:1px solid var(--line);max-width:none}
.prose p{margin:0 0 1.2em;max-width:none}
.prose h2{font-size:clamp(1.9rem,3.6vw,2.5rem);margin:1.9em 0 .6em}
.prose h3{margin:1.6em 0 .5em}
.prose ul,.prose ol{margin:0 0 1.3em 1.3em}
.prose li{margin-bottom:.55em;padding-left:.3em}
.prose li::marker{color:var(--burg);font-weight:600}
.prose a{color:var(--burg);text-underline-offset:3px}
.prose a:hover{color:var(--burg2)}
.prose strong{font-weight:600}
.prose blockquote{border-left:3px solid var(--burg);padding:4px 0 4px 22px;margin:1.6em 0;color:#2A2A34;font-family:'EB Garamond',Garamond,serif;font-size:1.35rem;line-height:1.5}
.prose hr{border:0;border-top:1px solid var(--line);margin:2.2em 0}
.prose img{height:auto;margin:1.6em 0}
.prose table{width:100%;border-collapse:collapse;margin:1.6em 0;font-size:.92rem}
.prose th,.prose td{border-bottom:1px solid var(--line);padding:10px 12px;text-align:left;vertical-align:top}
.prose th{font-weight:600;font-size:.76rem;letter-spacing:.12em;text-transform:uppercase;color:var(--steel)}
.prose em.note{display:block;font-style:normal;font-size:.85rem;color:var(--steel);border-top:1px solid var(--line);padding-top:16px;margin-top:2.4em}

.cta{background:var(--night);color:var(--warm);padding:clamp(28px,4vw,44px);margin:44px 0 0;border-top:3px solid var(--burg)}
.cta h2{color:var(--warm);font-size:clamp(1.8rem,3.4vw,2.4rem);margin-bottom:14px}
.cta p{color:#C9C9C4;margin-bottom:24px;font-size:.98rem}

.more-posts{background:#fff;border-top:1px solid var(--line);padding:clamp(40px,6vw,72px) 0}
.more-posts h2{font-size:clamp(1.8rem,3.4vw,2.4rem);margin-bottom:6px}
.more-posts .cards{padding:26px 0 0}

@media(max-width:620px){
  .nh .logo svg{width:116px;height:38px}
  .nh nav{gap:16px}
  .nh nav a{font-size:.7rem;letter-spacing:.1em}
  .nh nav a.hide-s{display:none}
  .post .lede{font-size:1.06rem}
}
"""

css = "/* Project P Distribution GmbH - gemeinsame Styles fuer News/Blog. Schriften: SIL Open Font License. */\n" \
      "html{color-scheme:only light}\n" + fonts + "\n" + base + "\n" + btn + "\n" + skip + "\n" + mark + "\n" + footer + "\n" + news
open("site.css", "w", encoding="utf-8").write(css)
print("site.css", len(css))
